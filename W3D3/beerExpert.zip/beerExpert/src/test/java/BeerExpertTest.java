import cs472.model.BeerExpert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class BeerExpertTest {

    @Test
    public void getBrands() {
        List<String> expectedResult = new ArrayList<>();
        expectedResult.add("Jack Amber");
        expectedResult.add("Red Moose");

        BeerExpert beerExpert = new BeerExpert();
        List<String> result = beerExpert.getBrands("amber");
        assertEquals(expectedResult, result);
    }
}
