package cs472.servlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String action = request.getServletPath();
        if (action.equals("/calculate")) {
            doCalculation(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
    }

    private void doCalculation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Integer aFirst = Integer.parseInt(request.getParameter("addFirst"));
            Integer aSecond = Integer.parseInt(request.getParameter("addSecond"));
            Integer mFirst = Integer.parseInt(request.getParameter("mulFirst"));
            Integer mSecond = Integer.parseInt(request.getParameter("mulSecond"));
            Integer addResult = aFirst + aSecond;
            Integer mulResult = mFirst * mSecond;

            List<Integer> calcValues = Arrays.asList(aFirst, aSecond, mFirst, mSecond, addResult, mulResult);

            request.setAttribute("calcResults", calcValues);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
            dispatcher.forward(request, response);
        }


    }
}
