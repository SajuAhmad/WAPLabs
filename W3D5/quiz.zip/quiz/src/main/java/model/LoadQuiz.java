package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class LoadQuiz {
    static List<Questions> loadQuestions() {
        List<Questions> list = new ArrayList<>(
                Arrays.asList(
                        new Questions("[3, 1, 4, 1, 5, ? ]", "9", "PI"),
                        new Questions("[1, 1, 2, 3, 5, ? ]", "8", "Fibonacci"),
                        new Questions("[1, 4, 9, 16, 25, ? ]", "36", "Self Multiply"),
                        new Questions("[2, 3, 5, 7, 11, ? ]", "13", "Prime"),
                        new Questions("[1, 2, 4, 8, 16, ? ]", "32", "n x 2")
                ));
        return list;
    }

}
