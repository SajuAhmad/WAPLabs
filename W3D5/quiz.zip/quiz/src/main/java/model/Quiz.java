package model;

import java.util.List;

public class Quiz {
    private List<Questions> qList;
    private long totalScore;
    private Integer currIndex;

    public Quiz() {
        qList = LoadQuiz.loadQuestions();
        totalScore = 0;
        currIndex = 0;
    }

    // return total number of questions
    public long getNumQuestions() {
        return qList.size();
    }

    // return total score
    public long getNumCorrect() {
        return totalScore;
    }

    public long getCurrentQuestionIndex(){
        return (long)currIndex;
    }

    // return current question and move pointer to next question
    public String getCurrentQuestion() {
        return qList.get(currIndex).getQuestion();
    }
    public String getCurrentQuestionHint() { return qList.get(currIndex).getHint(); }

    // check if the answer is correct
    public boolean isCorrect(String answer) {
        if (qList.get(currIndex).getAnswer().equals(answer)) {
            return true;
        } else {
            return false;
        }
    }

    // adds 1 to the total score
    public void scoreAnswer() {
        totalScore++;
        currIndex++;
    }


}
