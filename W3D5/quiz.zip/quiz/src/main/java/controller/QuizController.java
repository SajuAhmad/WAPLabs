package controller;

import model.Quiz;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class QuizController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        HttpSession session = request.getSession();
        Quiz sessQuiz = (Quiz) session.getAttribute("quiz");
        String answer = request.getParameter("txtAnswer");
        String restart = request.getParameter("restart");
        String hint = request.getParameter("hint");
        RequestDispatcher quizPage = request.getRequestDispatcher("/quiz.jsp");
        RequestDispatcher finishPage = request.getRequestDispatcher("/finished.jsp");
        Integer attempt = (Integer) session.getAttribute("attempt");

        if (restart != null) {
            session.invalidate();
            doGet(request, response);
        } else if (hint != null) {
            session.setAttribute("hint", true);
            quizPage.forward(request, response);
        } else {
            try {
                if (attempt < 3) {
                    session.setAttribute("error", true);

                    if ((answer != null)) {
                        if (sessQuiz.isCorrect(answer)) {
                            session.setAttribute("error", false);
                            sessQuiz.scoreAnswer();
                            session.setAttribute("hint", false);
                            attempt = -1;
                            session.setAttribute("attempt", attempt);
                        }
                        attempt++;
                        session.setAttribute("attempt", attempt);
                    }

                    if (sessQuiz.getNumCorrect() == (sessQuiz.getNumQuestions())) {
                        finishPage.forward(request, response);
                    } else {
                        quizPage.forward(request, response);
                    }
                } else {
                    finishPage.forward(request, response);
                }
            } catch (Exception e) {
                doGet(request, response);
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        Quiz sessQuiz = (Quiz) session.getAttribute("quiz");
        if (sessQuiz == null) {
            sessQuiz = new Quiz();
            session.setAttribute("quiz", sessQuiz);
        }
        session.setAttribute("attempt", 0);
        RequestDispatcher quizPage = request.getRequestDispatcher("/quiz.jsp");
        quizPage.forward(request, response);
    }
}
