$(function () {
    $('#search').on("click", getData);
    $(document).on('click', '.comment-button', showComments);
});

function getData() {
    const userId = $("#user-id").val();
    $.get('https://jsonplaceholder.typicode.com/users', {id: userId}).done(loadUserData);
    $.get('https://jsonplaceholder.typicode.com/posts', {userId}).done(loadPosts);
}

function loadUserData(data) {
    console.log(data);
    const userId = $('#user-id').val();
    if (!data) {
        errorAlert("User information cannot be loaded!");
        return;
    }

    let userInfo = '';
    const user = data[0];
    if (user) {
        userInfo += `<h3>User Data</h3>`;
        userInfo += `Name: ${user.name}`;
        userInfo += `, Username: ${user.username}`;
        userInfo += `, Email: ${user.email}`;
        userInfo += `, Address: ${user.address.street}, ${user.address.suite}, ${user.address.city}, ${user.address.zipcode}`;
        userInfo += `, Geolocation: ${user.address.geo.lat}, ${user.address.geo.lng}`;
        userInfo += `, Phone: ${user.phone}`;
        userInfo += `, Website: ${user.website} `;
        userInfo += `, Company: ${user.company.name}`;
        userInfo += `, Company catch phrase: ${user.company.catchPhrase}`;
        userInfo += `, Company bs: ${user.company.bs}`;
    } else {
        errorAlert("User id (" + userId + ") not found!");
    }

    $('#user-data').html(userInfo);
}

function loadPosts(data) {
    const userId = $('#user-id').val();
    if (!data) {
        errorAlert("User information cannot be loaded!");
        return;
    }
    let posts = '';

    if (data) {
        for (const post of data) {
            posts += `<h2>#${post.id} ${post.title}</h2>`;
            posts += `<p>${post.body}</p>`;
            posts += `<button type="button" class="comment-button" postId="${post.id}">Show comments</button>`;
            posts += '<div id="comment"></div>';
        }
    } else {
        posts = 'No post found!';
    }

    $('#posts').html(posts);
}

function showComments(e) {
    const postId = this.getAttribute('postid');
    if (postId) {
        $.get('https://jsonplaceholder.typicode.com/comments', {postId}).done(displayPostComments(postId));
    } else {
        errorAlert("No comment found!");
    }
}

function displayPostComments(postId) {
    return function (data) {
        if (!data) {
            showError("No comment found!");
            return;
        }

        let comments = '';
        if (data) {
            for (const comment of data) {
                comments += `#${comment.id} <h2>${comment.name}</h2>${comment.email}`;
                comments += `<p>${comment.body}</p>`;
            }
        } else {
            comments = 'No comment found!';
        }

        $("#comment").html(commentsHtml);
    };
}

function errorAlert(error) {
    alert(error);
}