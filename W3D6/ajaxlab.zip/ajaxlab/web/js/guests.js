$(function () {
    $("#send").on("click", updateGuests);
});

function updateGuests() {
    let first = $("#first").val();
    let last = $("#last").val();

    $.ajax("partyplanner", {
        "type": "post",
        "data": {
            "first": first,
            "last": last
        }
    }).done(displayGuests);
}

function displayGuests(data) {
    let guestList = "<ul>";
    if (data) {
        for (let element of data) {
            guestList += "<li>" + element.first + " " + element.last +"</li>";
        }
    }
    guestList += "</ul>";
    $("#guestList").html(guestList);
}